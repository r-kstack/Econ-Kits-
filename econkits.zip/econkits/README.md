# EconKits

Free, complete HSC Economics teaching kits for schools without a specialist economics teacher. Static site — no build step, no dependencies.

## Structure

```
index.html              Home page
kits.html               Kit library
about.html              Mission, evidence, contact
assets/style.css        All styling
kits/                   Kit files (PDFs, slides) live here
  intro-to-economics/   Kit 01 files — drop teacher-guide.pdf etc. in here
```

## Publish with GitHub Pages

1. Create a public repo named `econkits` and push these files to the `main` branch.
2. On GitHub: **Settings → Pages → Source: Deploy from a branch → Branch: main / (root) → Save**.
3. The site goes live at `https://<your-username>.github.io/econkits/` within a minute or two. Every push republishes automatically.

## Add the custom domain (econkits.org)

1. Buy the domain (Cloudflare Registrar or Namecheap, ~AU$20/yr).
2. At the registrar, add DNS records:
   - `CNAME` record: name `www`, value `<your-username>.github.io`
   - Four `A` records for the apex (`econkits.org`): `185.199.108.153`, `185.199.109.153`, `185.199.110.153`, `185.199.111.153`
3. On GitHub: **Settings → Pages → Custom domain → econkits.org → Save**, then tick **Enforce HTTPS** once the certificate is issued (can take up to an hour).
4. GitHub will create a `CNAME` file in the repo — leave it there.

## Before publishing — checklist

- [ ] Replace `[name]` on `about.html` (and remove the HTML comment there)
- [ ] Set up the `hello@econkits.org` email (Cloudflare Email Routing forwards it to your personal address free) or swap in an address you control
- [ ] Drop the real kit files into `kits/intro-to-economics/` and check the download links on `kits.html`
- [ ] Update the GitHub footer links to your repo URL
- [ ] Only claim "reviewed by experienced HSC Economics teachers" once that has actually happened

## Adding a new kit later

1. Create a folder under `kits/`, e.g. `kits/consumers-and-business/`, and add the files.
2. On `kits.html`, copy the Kit 01 `<article class="kit">` block, update the text and links, and change the upcoming kit's badge from `badge-soon` to `badge-live`.

## Licence

Site code: MIT. Teaching materials: CC BY-NC 4.0.
